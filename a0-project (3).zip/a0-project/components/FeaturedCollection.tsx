import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';

const SCREEN_WIDTH = Dimensions.get('window').width;

export default function FeaturedCollection() {
  const collections = [    {
      id: 1,
      title: 'Designer Suits',
      image: `https://api.a0.dev/assets/image?text=professional%20mens%20luxury%20suit%20fashion%20photography&aspect=4:5`,
      price: '₹95,999'
    },
    {
      id: 2,
      title: 'Premium Shirts',
      image: `https://api.a0.dev/assets/image?text=luxury%20mens%20dress%20shirt%20fashion%20photography&aspect=4:5`,
      price: '₹22,999'
    },
    {
      id: 3,
      title: 'Designer Accessories',
      image: `https://api.a0.dev/assets/image?text=luxury%20mens%20accessories%20watch%20leather%20goods&aspect=4:5`,
      price: '₹38,999'
    }
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>Featured Collection</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {collections.map((item) => (
          <TouchableOpacity key={item.id} style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.cardContent}>
              <Text style={styles.itemTitle}>{item.title}</Text>
              <Text style={styles.price}>{item.price}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 30,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 20,
    paddingHorizontal: 20,
  },
  scrollContent: {
    paddingHorizontal: 15,
  },
  card: {
    width: SCREEN_WIDTH * 0.7,
    maxWidth: 300,
    marginHorizontal: 5,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  image: {
    width: '100%',
    height: 400,
    resizeMode: 'cover',
  },
  cardContent: {
    padding: 15,
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 5,
  },
  price: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
});
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Header() {
  return (
    <SafeAreaView style={styles.header}>
      <View style={styles.headerContent}>      <Text style={styles.logo}>रुतबा</Text>
        <View style={styles.navItems}>
          <TouchableOpacity style={styles.navItem}>
            <Text style={styles.navText}>Collections</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem}>
            <Text style={styles.navText}>New Arrivals</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.cartButton}>
            <Feather name="shopping-bag" size={20} color="#1a1a1a" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  logo: {
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: 2,
    color: '#1a1a1a',
  },
  navItems: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  navItem: {
    paddingVertical: 5,
  },
  navText: {
    fontSize: 16,
    color: '#1a1a1a',
    fontWeight: '500',
  },
  cartButton: {
    padding: 8,
  },
});
import { View, Text, ImageBackground, StyleSheet, TouchableOpacity } from 'react-native';

export default function Hero() {
  return (
    <ImageBackground
      source={{ uri: `https://api.a0.dev/assets/image?text=luxury%20mens%20fashion%20model%20in%20suit%20professional%20photography&aspect=16:9` }}
      style={styles.hero}
    >
      <View style={styles.overlay}>
        <View style={styles.content}>          <Text style={styles.title}>शाही परिधान</Text>
          <Text style={styles.subtitle}>
            Experience the finest in luxury menswear
          </Text>
          <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>Shop Now</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  hero: {
    height: 600,
    width: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 48,
    fontWeight: '700',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: 1,
  },
  subtitle: {
    fontSize: 18,
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 30,
    maxWidth: 500,
  },
  button: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 30,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
  },
});
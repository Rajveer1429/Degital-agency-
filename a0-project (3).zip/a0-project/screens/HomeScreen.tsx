import { ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Header from '../components/Header';
import Hero from '../components/Hero';
import FeaturedCollection from '../components/FeaturedCollection';

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <Header />
      <Hero />
      <FeaturedCollection />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
});
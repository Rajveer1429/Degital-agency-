import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Zap, Share2, BarChart, Globe, Mail, PenTool, FileCode, Smartphone } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Services</h1>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                  Comprehensive digital marketing solutions tailored to your business needs
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
              <Card>
                <CardHeader className="pb-2">
                  <Search className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Search Engine Optimization</CardTitle>
                  <CardDescription>Improve your visibility in search results</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our SEO services include keyword research, on-page optimization, technical SEO, and link building to
                    improve your organic rankings.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/seo">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Zap className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>PPC Advertising</CardTitle>
                  <CardDescription>Drive targeted traffic to your website</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our PPC services include campaign setup, ad creation, bid management, and performance optimization
                    across Google, Bing, and social platforms.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/ppc">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Share2 className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Social Media Marketing</CardTitle>
                  <CardDescription>Engage with your audience effectively</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our social media services include content creation, community management, paid social campaigns, and
                    performance analytics.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/social-media">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <BarChart className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Analytics & Reporting</CardTitle>
                  <CardDescription>Data-driven insights for your business</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our analytics services include setup, tracking, custom reporting, and actionable insights to improve
                    your marketing ROI.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/analytics">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Globe className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Web Design & Development</CardTitle>
                  <CardDescription>Create a stunning online presence</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our web services include responsive design, UX/UI optimization, e-commerce development, and CMS
                    implementation.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/web-design">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Mail className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Email Marketing</CardTitle>
                  <CardDescription>Nurture leads and drive conversions</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our email marketing services include campaign strategy, template design, automation, segmentation,
                    and performance analysis.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/email-marketing">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <PenTool className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Content Marketing</CardTitle>
                  <CardDescription>Engage your audience with valuable content</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our content services include strategy development, blog writing, ebooks, infographics, video
                    production, and distribution.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/content-marketing">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <FileCode className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Conversion Rate Optimization</CardTitle>
                  <CardDescription>Turn visitors into customers</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our CRO services include user behavior analysis, A/B testing, landing page optimization, and funnel
                    analysis.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/cro">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <Smartphone className="h-6 w-6 text-primary mb-2" />
                  <CardTitle>Mobile Marketing</CardTitle>
                  <CardDescription>Reach customers on their devices</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our mobile marketing services include app store optimization, SMS marketing, mobile advertising, and
                    responsive design.
                  </p>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/services/mobile-marketing">Learn More</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

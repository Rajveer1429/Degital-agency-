export function Stats() {
  return (
    <section className="w-full py-12 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="space-y-2">
            <h2 className="text-4xl font-bold">10+</h2>
            <p className="text-muted-foreground">Years Experience</p>
          </div>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold">500+</h2>
            <p className="text-muted-foreground">Happy Clients</p>
          </div>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold">50+</h2>
            <p className="text-muted-foreground">Digital Experts</p>
          </div>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold">15+</h2>
            <p className="text-muted-foreground">Industry Awards</p>
          </div>
        </div>
      </div>
    </section>
  )
}

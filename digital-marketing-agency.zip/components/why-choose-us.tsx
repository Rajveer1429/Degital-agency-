import { TrendingUp, Users, Award } from "lucide-react"

export function WhyChooseUs() {
  return (
    <section className="w-full py-12 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-start space-y-4">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Why Choose BritDigital?</h2>
          <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
            With over a decade of experience, we deliver measurable results through tailored digital marketing
            strategies. Our data-driven approach ensures that your marketing investment generates real business growth.
          </p>
        </div>
        <div className="grid gap-6 mt-8 md:grid-cols-1 lg:grid-cols-3">
          <div className="flex items-start space-x-4">
            <div className="mt-1">
              <TrendingUp className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Data-Driven Strategies</h3>
              <p className="text-muted-foreground">We make decisions based on analytics and performance data</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <div className="mt-1">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Expert Team</h3>
              <p className="text-muted-foreground">Our specialists are certified and continuously trained</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <div className="mt-1">
              <Award className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Award-Winning Results</h3>
              <p className="text-muted-foreground">Recognized excellence in digital marketing campaigns</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

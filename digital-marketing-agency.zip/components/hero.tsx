import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export function Hero() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Innovative
                <br />
                Digital
                <br />
                Marketing
                <br />
                Solutions
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Elevate your brand with data-driven strategies tailored for measurable growth and lasting impact.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Get a Quote</Button>
              <Button variant="outline" asChild>
                <Link href="/services">Services</Link>
              </Button>
            </div>
          </div>
          <div className="flex justify-center">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Digital Marketing Services"
              width={600}
              height={400}
              className="rounded-lg object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

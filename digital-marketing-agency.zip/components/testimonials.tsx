import { Card, CardContent } from "@/components/ui/card"
import { Quote } from "lucide-react"

export function Testimonials() {
  return (
    <section className="w-full py-12 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Clients Say</h2>
          <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
            We pride ourselves on delivering exceptional results for businesses across the UK
          </p>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:grid-cols-3 mt-12">
          <Card>
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4 opacity-70" />
              <p className="mb-4">
                BritDigital transformed our online presence. Their SEO strategy doubled our organic traffic and
                significantly increased conversions.
              </p>
              <div className="border-t pt-4">
                <p className="font-medium">London Retail Ltd</p>
                <p className="text-sm text-muted-foreground">London</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4 opacity-70" />
              <p className="mb-4">
                Working with BritDigital has been a game-changer for our business. Their team is responsive,
                knowledgeable, and delivered real results.
              </p>
              <div className="border-t pt-4">
                <p className="font-medium">Manchester Tech</p>
                <p className="text-sm text-muted-foreground">Manchester</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <Quote className="h-8 w-8 text-primary mb-4 opacity-70" />
              <p className="mb-4">
                The PPC campaign BritDigital created for us has generated an impressive ROI. Their data-driven approach
                and continuous optimization make all the difference.
              </p>
              <div className="border-t pt-4">
                <p className="font-medium">Glasgow Services</p>
                <p className="text-sm text-muted-foreground">Glasgow</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

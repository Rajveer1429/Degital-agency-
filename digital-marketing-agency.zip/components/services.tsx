import { Search, Zap, Share2, ArrowRight } from "lucide-react"
import Link from "next/link"

export function Services() {
  return (
    <section className="w-full py-12 md:py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Our Digital Marketing Services
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
              Comprehensive solutions to boost your online presence and drive business growth
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          <div className="flex flex-col p-6 bg-card rounded-lg shadow-sm">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
              <Search className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">SEO</h3>
            <p className="mt-2 text-muted-foreground">
              Improve your website's visibility in search engines and drive organic traffic.
            </p>
            <Link href="/services/seo" className="mt-4 inline-flex items-center text-primary hover:underline">
              Learn More <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="flex flex-col p-6 bg-card rounded-lg shadow-sm">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
              <Zap className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">PPC Advertising</h3>
            <p className="mt-2 text-muted-foreground">
              Targeted pay-per-click advertising campaigns that deliver immediate results.
            </p>
            <Link href="/services/ppc" className="mt-4 inline-flex items-center text-primary hover:underline">
              Learn More <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="flex flex-col p-6 bg-card rounded-lg shadow-sm">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
              <Share2 className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Social Media Marketing</h3>
            <p className="mt-2 text-muted-foreground">
              Build your brand presence and engage with your audience on social platforms.
            </p>
            <Link href="/services/social-media" className="mt-4 inline-flex items-center text-primary hover:underline">
              Learn More <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
        <div className="flex justify-center mt-8">
          <Link
            href="/services"
            className="inline-flex items-center justify-center rounded-md bg-card px-6 py-3 text-sm font-medium shadow-sm transition-colors hover:bg-muted"
          >
            View All Services <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  )
}
